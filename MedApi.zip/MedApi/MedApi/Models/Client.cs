﻿namespace MedApi.Models
{
    public class Client
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string iin { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
    }
}
