﻿namespace MedApi.Models
{
    public class Analysis
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Group { get; set; }
        public string GroupName { get; set; }
    }
}
 