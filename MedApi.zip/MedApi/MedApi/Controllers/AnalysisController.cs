﻿using MedApi.Interfaces;
using MedApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace MedApi.Controllers
{
    public class AnalysisController : Controller
    {
        [ApiController]
        [Route("api")]
        public class ClientController : Controller
        {
            private readonly IAnalysisRepository _analysisRepository;

            [HttpGet("[action]")]
            public IActionResult GetAllAnalysis() => Ok(_analysisRepository.GetAllAnalysis());

          /*  [HttpPost("[action]")]
            public IActionResult Registration(Client client)
            {
                ApiResponse<bool> result = _clientRepository.Registration(client);
                return Ok(result);
            }
          */
        }

    }
}
