﻿using MedApi.Interfaces;
using MedApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace MedApi.Controllers
{
    [ApiController]
    [Route("api")]
    public class ClientController : Controller
    {
        private readonly IClientRepository _clientRepository;


        /*
        public IActionResult Registration([FromBody] Client client) => Ok(_clientRepository.Registration(client));
        */
        [HttpPost("[action]")]
        public JsonResult/*IActionResult*/ Registration([FromBody] Client client)
        {
            ApiResponse<bool> result = new ApiResponse<bool>();
            //_clientRepository.Registration(client);
            // return Ok(Json.result);
            return new JsonResult(result);        
        }
        



    }
}
