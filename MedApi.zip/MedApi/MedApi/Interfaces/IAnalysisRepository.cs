﻿using MedApi.Models;

namespace MedApi.Interfaces
{
    public interface IAnalysisRepository
    {
        public ApiResponse<Analysis> GetAllAnalysis();
    }
}
