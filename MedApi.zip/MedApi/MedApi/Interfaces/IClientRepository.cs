﻿using MedApi.Models;

namespace MedApi.Interfaces
{
    public interface IClientRepository
    {
        public ApiResponse<bool> Registration(Client client);

    }
}
