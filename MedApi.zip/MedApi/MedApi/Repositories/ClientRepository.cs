﻿using MedApi.Interfaces;
using MedApi.Models;
using System.Data.SqlClient;

namespace MedApi.Repositories
{
    public class ClientRepository: IClientRepository
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public ClientRepository(IConfiguration configuration)
        {
            this._configuration = configuration;
            this._connectionString = configuration.GetConnectionString("Connection");
        }

        public ApiResponse<bool> Registration(Client client) 
        { 
            ApiResponse<bool> response = new ApiResponse<bool>();

            try
            {
/*
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("dbo.p_PostClientData", conn))
                    {
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@FirstName", client.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", client.LastName);
                        cmd.Parameters.AddWithValue("@IIN", client.IIN);
                        cmd.Parameters.AddWithValue("@Email", client.Email);
                        cmd.Parameters.AddWithValue("@Phone", client.Phone);
                        
                        cmd.ExecuteNonQuery();
                    }
                }*/
            }
            catch (Exception ex)
            {
                response.Code = -1;
                response.Message = ex.Message;
            }

            return response;
        } 

       

    }
}
