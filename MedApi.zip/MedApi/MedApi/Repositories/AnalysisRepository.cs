﻿namespace MedApi.Repositories
{
    public class AnalysisRepository
    {

    }
}
