﻿using PromoCode.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Net.Http;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PromoCode;
using Alser.AutoDataManager;
using System.Data;
using System.IO;

namespace SendPromocodes
{
    class Program
    {
        static void Main(string[] args)
        {
            //  Получение мастер заказов для отправки купонов
            ApiResponse<List<MasterNumberModel>> response = GetMasterModels();

            if (response.Code != 0)
            {
                return;
            }
            if (response.Data == null)
            {
                return;
            }

            List<Response> Promocodes = new List<Response>();

            // Получение купона для отправки смс
            foreach (MasterNumberModel model in response.Data)
            {
                if (model.MasterNumber == 0 || model.Sum == 0)
                    continue;
                else
                {
                    string ConnectionString = String.Format("http://promotionmaster.next.local/api/api/a/GeneratePromocodes/272/1/{0}/{1}", model.Sum, model.MasterNumber);
                    using (HttpClient client = new HttpClient())
                    {
                        var responses = client.GetAsync(ConnectionString).GetAwaiter().GetResult();
                        if (responses.IsSuccessStatusCode)
                        {
                            var responseContent = responses.Content;
                            var responseBody = responseContent.ReadAsStringAsync().GetAwaiter().GetResult();
                            var json = JsonConvert.DeserializeObject<Response>(responseBody);
                            var jObject = JObject.Parse(responseBody);
                            var records = jObject["data"]
                                .Children()
                                .Select(i => i.ToObject<Response>())
                                .ToList();
                            Promocodes.Add(new Response() { MasterNumber = records[0].MasterNumber, PromoCode = records[0].PromoCode, Sum = records[0].Sum, EndDate = records[0].EndDate, InsertDate = records[0].InsertDate, BeginDate = records[0].BeginDate, StatusId = records[0].StatusId });
                        }
                    }
                }
            }

            //Данные для DataTable
            List<BasketSMS> SMS = new List<BasketSMS>();
            foreach (Response model in Promocodes)
            {
                SMS.Add(new BasketSMS()
                {
                    MasterNumber = model.MasterNumber,
                    SMSText_1 = String.Format("Vam nachislen kupon na summu {0} tg. Oplati im 30% ot stoimosti sleduyushchey pokupki. Promokod {1} aktiviruetsya {2}", model.Sum, model.PromoCode, model.BeginDate),
                    SMSText_2 = String.Format("Vash kupon na skidku {0} tg activirovan i dostupen do {1}. Promokod {2}. Uspei potratit' v magazinah ili na saite Alser.kz info:3003", model.Sum, model.EndDate, model.PromoCode),
                    Sum = model.Sum,
                    StatusId = model.StatusId,
                });
                
            }

            // Отправка СМС
            ApiResponse <string> postsms = PostSMS(SMS);

            if (postsms != null)
                Console.WriteLine("СМСки отправлены!");

        }

        public static ApiResponse<List<MasterNumberModel>> GetMasterModels()
        {
            ApiResponse<List<MasterNumberModel>> response = new ApiResponse<List<MasterNumberModel>>();
            List<MasterNumberModel> lists = new List<MasterNumberModel>();
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=10.0.1.45;Initial Catalog=WebProject;Integrated Security=true;MultipleActiveResultSets=True;Application Name=Info"))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("dbo.GetMasterNumbersForPromocodes", connection);

                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            MasterNumberModel model = new MasterNumberModel();
                            model.MasterNumber = reader["MasterNum"] == DBNull.Value ? 0 : Convert.ToInt32(reader["MasterNum"]);
                            model.Sum = reader["Sum"] == DBNull.Value ? 0 : Convert.ToInt32(reader["Sum"]);
                            lists.Add(model);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                response.Code = -1;
                response.Message = e.Message;
            }
            response.Data = lists;
            return response;
        }

            public static ApiResponse<string> PostSMS(List<BasketSMS> Promocodes)
        {
            DataTable datatable = new DataTable();
            datatable.Columns.Add("MasterNumber", typeof(int));
            datatable.Columns.Add("SMSText_1", typeof(string));
            datatable.Columns.Add("SMSText_2", typeof(string));
            datatable.Columns.Add("StatusId", typeof(int));
            datatable.Columns.Add("InsertDate", typeof(DateTime));
            datatable.Columns.Add("SendAfterDate_1", typeof(DateTime));
            datatable.Columns.Add("SendAfterDate_2", typeof(DateTime));
            datatable.Columns.Add("AttemptsCount", typeof(int));

            DataRow row;
            for(int i = 0; i < Promocodes.Count; i++)
            {
                row = datatable.NewRow();
                row[0] = Promocodes[i].MasterNumber;
                row[1] = Promocodes[i].SMSText_1;
                row[2] = Promocodes[i].SMSText_2;
                row[3] = 1;
                row[4] = DateTime.Now;
                row[5] = DateTime.Now;
                row[6] = DateTime.Now.AddDays(14);
                row[7] = 0;
                datatable.Rows.Add(row);
            }



            ApiResponse<string> response = new ApiResponse<string>();

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=1c-db;Initial Catalog=AlserPromotionMaster;Integrated Security=true;MultipleActiveResultSets=True;Application Name=Info"))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("dbo.p_PostPromocodesForSMS", connection);
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@dataTable", datatable);
                    SqlDataReader reader = command.ExecuteReader();

                    List<int> model = new List<int>();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var m = Convert.ToInt32(reader["MasterNumber"]);
                            model.Add(m);
                        }
                    }

                 //   List<int> MasterNum = new List<int>();
                    DataTable data = new DataTable();
                    data.Columns.Add("MasterNumber", typeof(int));

                    DataRow rows;
                    for (int i = 0; i < model.Count; i++)
                    {
                        rows = data.NewRow();
                        rows[0] = model[i];
                        data.Rows.Add(rows);
                    }

                    using (SqlConnection con = new SqlConnection("Data Source=10.0.1.45;Initial Catalog=WebProject;Integrated Security=true;MultipleActiveResultSets=True;Application Name=Info"))
                    {
                        con.Open();
                        SqlCommand com = new SqlCommand("dbo.p_SMSIsSendUpdate", con);
                        com.CommandType = System.Data.CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("@dataTable", data);
                        int rowCount = com.ExecuteNonQuery();
                    }
                }
            }

            catch(Exception e)
            {
                response.Code = -1;
                response.Message = e.Message;
            }
            return response;
        }
    }
}
