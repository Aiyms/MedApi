﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace PromoCode.models
{
    class BasketSMS
    {
        public int MasterNumber { get; set; }
        public string SMSText_1 { get; set; }
        public string SMSText_2 { get; set; }
        public int Sum { get; set; }
        public int StatusId { get; set; }
        public DateTime InsertDate { get; set; }
        public DateTime SendAfterDate_1 { get; set; }
        public DateTime SendAfterDate_2 { get; set; }
        public int AttemptsCount { get; set; }
    }
}
