﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromoCode.models
{
    class MasterNumberModel
    {
        public int MasterNumber { get; set; }
        public int Sum { get; set; }
    }
}
