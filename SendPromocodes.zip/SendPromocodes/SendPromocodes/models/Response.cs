﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace PromoCode.models
{
    class Response
    {
        
        [JsonProperty("generatedByMasterNumber")]
        public int MasterNumber { get; set; }

        [JsonProperty("promocode")]
        public string PromoCode { get; set; }

        [JsonProperty("denomination")]
        public int Sum { get; set; }

        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        [JsonProperty("insertDate")]
        public DateTime InsertDate { get; set; }
        [JsonProperty("beginDate")]
        public DateTime BeginDate { get; set; }

        [JsonProperty("statusId")]
        public int StatusId { get; set; }

    }
}
