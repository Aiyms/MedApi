﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromoCode.models
{
    public class ApiResponse<T>
    {
        public int Code { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }

        public static ApiResponse<T> DoMethod(Action<ApiResponse<T>> action)
        {
            ApiResponse<T> result = new ApiResponse<T>();
            try
            {
                action(result);
            }
            catch (Exception e)
            {
                result.Code = -1;
                result.Message = e.Message;
            }

            return result;
        }
    }
}
